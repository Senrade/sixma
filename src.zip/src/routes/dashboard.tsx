import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/SiteChrome";
import { PixelLink } from "@/components/PixelButton";
import { CASES } from "@/lib/game-data";
import { T, useLang } from "@/lib/i18n";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "Bảng điều khiển điều tra viên — VERITAS.EXE" },
      {
        name: "description",
        content: "Theo dõi tiến độ hồ sơ, huy hiệu và chuỗi ngày luyện kiểm chứng.",
      },
      { property: "og:title", content: "Bảng điều khiển điều tra viên — VERITAS.EXE" },
      { property: "og:description", content: "Tiến độ, huy hiệu và chuỗi ngày của bạn." },
    ],
  }),
  component: DashboardPage,
});

function DashboardPage() {
  const { t } = useLang();

  const stats = [
    ["1/3", T.statDone],
    ["4", T.statCards],
    ["7", T.statStreak],
    ["820", T.statScore],
  ] as const;
  const badges = [T.badge1, T.badge2, T.badge3, T.badge4];

  return (
    <PageShell>
      <section className="mx-auto max-w-6xl px-4 py-16">
        <p className="label-mono text-primary">{t(T.dashKicker)}</p>
        <h1 className="mt-3 text-4xl font-bold sm:text-5xl">{t(T.dashTitle)}</h1>

        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map(([v, l]) => (
            <div key={v} className="pixel-frame p-5">
              <p className="font-display text-3xl font-bold text-gold">{v}</p>
              <p className="label-mono mt-1 text-muted-foreground">{t(l)}</p>
            </div>
          ))}
        </div>

        <div className="mt-10 grid gap-6 lg:grid-cols-[1.4fr_1fr]">
          <div className="pixel-frame p-6">
            <h2 className="text-xl font-bold">{t(T.caseProgress)}</h2>
            <div className="mt-5 grid gap-4">
              {CASES.map((c, i) => {
                const pct = i === 0 ? 100 : 0;
                return (
                  <div key={c.id}>
                    <div className="flex items-center justify-between font-display text-sm uppercase tracking-wider">
                      <span>
                        {c.code} · {t(c.title)}
                      </span>
                      <span className="text-primary">{pct}%</span>
                    </div>
                    <div className="mt-2 h-4 border-[3px] border-input bg-surface-2">
                      <div
                        className="h-full bg-primary"
                        style={{ width: `${pct}%` }}
                        aria-hidden="true"
                      />
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="mt-6">
              <PixelLink to="/cases" variant="gold">
                {t(T.continueCase)}
              </PixelLink>
            </div>
          </div>

          <div className="pixel-frame p-6">
            <h2 className="text-xl font-bold">{t(T.badges)}</h2>
            <div className="mt-5 grid gap-3">
              {badges.map((b, i) => (
                <div
                  key={b.en}
                  className={`flex items-center gap-3 border-[3px] px-4 py-3 font-display text-sm uppercase tracking-wider ${
                    i === 0
                      ? "border-neon bg-neon text-neon-foreground"
                      : "border-input bg-surface-2 text-muted-foreground"
                  }`}
                >
                  <span>{i === 0 ? "★" : "☆"}</span>
                  {t(b)}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </PageShell>
  );
}
