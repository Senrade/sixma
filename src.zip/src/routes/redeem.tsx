import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageShell } from "@/components/SiteChrome";
import { PixelButton } from "@/components/PixelButton";
import { T, useLang } from "@/lib/i18n";

export const Route = createFileRoute("/redeem")({
  head: () => ({
    meta: [
      { title: "Nhập mã thẻ điều tra — VERITAS.EXE" },
      {
        name: "description",
        content: "Nhập mã thẻ lớp học để mở khoá hồ sơ điều tra trong VERITAS.EXE.",
      },
      { property: "og:title", content: "Nhập mã thẻ điều tra — VERITAS.EXE" },
      { property: "og:description", content: "Mở khoá hồ sơ bằng mã thẻ giấy phát tại lớp." },
    ],
  }),
  component: RedeemPage,
});

function RedeemPage() {
  const { t } = useLang();
  const [code, setCode] = useState("");
  const [state, setState] = useState<"idle" | "ok" | "bad">("idle");

  return (
    <PageShell>
      <section className="mx-auto max-w-2xl px-4 py-20">
        <p className="label-mono text-accent">{t(T.redeemKicker)}</p>
        <h1 className="mt-3 text-4xl font-bold sm:text-5xl">{t(T.redeemTitle)}</h1>
        <p className="mt-4 text-muted-foreground">
          {t(T.redeemText)} <span className="text-primary">VRT-XXXX</span>.
        </p>

        <form
          className="pixel-frame mt-8 grid gap-4 p-6"
          onSubmit={(e) => {
            e.preventDefault();
            setState(/^VRT-[A-Z0-9]{4}$/i.test(code.trim()) ? "ok" : "bad");
          }}
        >
          <label className="label-mono text-muted-foreground" htmlFor="code">
            {t(T.redeemLabel)}
          </label>
          <input
            id="code"
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            placeholder="VRT-2026"
            className="border-[3px] border-input bg-surface-2 px-4 py-3 font-display text-lg tracking-[0.25em] text-foreground outline-none placeholder:text-muted-foreground/60 focus:border-primary"
          />
          <PixelButton type="submit" variant="gold">{t(T.redeemBtn)}</PixelButton>

          {state === "ok" && (
            <p className="border-[3px] border-neon bg-neon px-4 py-3 font-display text-sm uppercase tracking-wider text-neon-foreground">
              {t(T.redeemOk)}
            </p>
          )}
          {state === "bad" && (
            <p className="border-[3px] border-destructive bg-destructive px-4 py-3 font-display text-sm uppercase tracking-wider text-destructive-foreground">
              {t(T.redeemBad)}
            </p>
          )}
        </form>
      </section>
    </PageShell>
  );
}
