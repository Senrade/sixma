import { createFileRoute, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { PageShell } from "@/components/SiteChrome";
import { PixelButton, PixelLink } from "@/components/PixelButton";
import { CASES, type GameCase } from "@/lib/game-data";
import { T, useLang } from "@/lib/i18n";

export const Route = createFileRoute("/cases/$caseId")({
  loader: ({ params }) => {
    const found = CASES.find((c) => c.id.toLowerCase() === params.caseId.toLowerCase());
    if (!found) throw notFound();
    return found;
  },
  head: ({ loaderData }) => {
    const c = loaderData as GameCase | undefined;
    return {
      meta: [
        { title: `${c?.code ?? "Hồ sơ"} — ${c?.title.vi ?? ""} | VERITAS.EXE` },
        { name: "description", content: c?.tagline.vi ?? "Hồ sơ điều tra tin giả." },
        { property: "og:title", content: `${c?.code ?? ""} — ${c?.title.vi ?? ""}` },
        { property: "og:description", content: c?.tagline.vi ?? "" },
      ],
    };
  },
  component: CaseDetail,
});

function CaseDetail() {
  const c = Route.useLoaderData() as GameCase;
  const { t } = useLang();
  const [picked, setPicked] = useState<string | null>(null);
  const [found, setFound] = useState<string[]>([]);
  const locked = c.status === "locked";

  const choices = [
    { id: "a", label: T.choiceA, right: false },
    { id: "b", label: T.choiceB, right: true },
    { id: "c", label: T.choiceC, right: false },
  ];

  return (
    <PageShell>
      <section className="border-b-[3px] border-border bg-surface/60">
        <div className="mx-auto max-w-5xl px-4 py-12">
          <div className="flex flex-wrap items-center gap-3">
            <span className="border-[3px] border-gold px-2 py-1 font-display text-xs font-bold tracking-widest text-gold">
              {t(T.fileWord)} {c.code}
            </span>
            <span className="border-[3px] border-accent bg-accent px-2 py-1 font-display text-xs font-bold tracking-widest text-accent-foreground">
              {t(T.level)} {c.threat}
            </span>
            <span className="label-mono text-muted-foreground">
              {c.minutes} {t(T.minutes)} · {c.modules} {t(T.modules)}
            </span>
          </div>
          <h1 className="mt-4 text-4xl font-bold sm:text-5xl">{t(c.title)}</h1>
          <p className="mt-3 max-w-2xl text-muted-foreground">{t(c.briefing)}</p>
        </div>
      </section>

      {locked ? (
        <section className="mx-auto max-w-3xl px-4 py-24 text-center">
          <p className="font-display text-6xl font-bold text-primary caret-blink">▮</p>
          <h2 className="mt-6 text-2xl font-bold">{t(T.sealedTitle)}</h2>
          <p className="mt-3 text-muted-foreground">{t(T.sealedText)}</p>
          <div className="mt-8 flex justify-center">
            <PixelLink to="/cases">{t(T.backToHub)}</PixelLink>
          </div>
        </section>
      ) : (
        <section className="mx-auto grid max-w-5xl gap-8 px-4 py-16">
          {/* Module 1 — evidence */}
          <article className="pixel-frame p-6">
            <p className="label-mono text-neon">{t(T.mod1)}</p>
            <h2 className="mt-3 text-2xl font-bold">{t(T.mod1Title)}</h2>
            <div className="mt-6 grid gap-3 sm:grid-cols-3">
              {c.evidence.map((e) => {
                const hit = found.includes(e.label);
                return (
                  <button
                    key={e.label}
                    onClick={() => setFound((f) => (f.includes(e.label) ? f : [...f, e.label]))}
                    className={`border-[3px] p-4 text-left transition-colors ${
                      hit
                        ? "border-neon bg-neon text-neon-foreground"
                        : "border-input bg-surface-2 text-foreground hover:border-primary"
                    }`}
                  >
                    <p className="font-display text-xs font-bold uppercase tracking-widest">
                      {e.label}
                    </p>
                    <p className="mt-2 text-sm">{hit ? t(e.note) : t(T.unanalyzed)}</p>
                  </button>
                );
              })}
            </div>
            <p className="mt-4 font-display text-sm uppercase tracking-widest text-primary">
              {t(T.progress)}: {found.length}/{c.evidence.length}
            </p>
          </article>

          {/* Module 2 — choice */}
          <article className="pixel-frame p-6">
            <p className="label-mono text-accent">{t(T.mod2)}</p>
            <h2 className="mt-3 text-2xl font-bold">{t(T.mod2Title)}</h2>
            <div className="mt-6 grid gap-3">
              {choices.map((ch) => {
                const active = picked === ch.id;
                return (
                  <button
                    key={ch.id}
                    onClick={() => setPicked(ch.id)}
                    className={`border-[3px] px-4 py-3 text-left font-display text-sm uppercase tracking-wider transition-colors ${
                      active
                        ? ch.right
                          ? "border-neon bg-neon text-neon-foreground"
                          : "border-destructive bg-destructive text-destructive-foreground"
                        : "border-input bg-surface-2 text-foreground hover:border-primary"
                    }`}
                  >
                    <span className="mr-3">[{ch.id.toUpperCase()}]</span>
                    {t(ch.label)}
                  </button>
                );
              })}
            </div>
            {picked && (
              <p className="mt-4 border-l-[6px] border-primary bg-surface-2 p-4 text-sm text-foreground">
                {picked === "b" ? t(T.verdictRight) : t(T.verdictWrong)}
              </p>
            )}
          </article>

          {/* Module 3 — chain */}
          <article className="pixel-frame p-6">
            <p className="label-mono text-warn">{t(T.mod3)}</p>
            <ol className="mt-6 grid gap-3">
              {[T.chain1, T.chain2, T.chain3, T.chain4].map((s, i) => (
                <li
                  key={s.en}
                  className="flex items-center gap-4 border-[3px] border-input bg-surface-2 px-4 py-3"
                >
                  <span className="font-display text-xl font-bold text-accent">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="font-display uppercase tracking-wider">{t(s)}</span>
                </li>
              ))}
            </ol>
            <div className="mt-6 flex flex-wrap gap-4">
              <PixelButton variant="gold" onClick={() => setFound(c.evidence.map((e) => e.label))}>
                {t(T.submit)}
              </PixelButton>
              <PixelLink to="/cases" variant="ghost">
                {t(T.hubKicker)}
              </PixelLink>
            </div>
          </article>
        </section>
      )}
    </PageShell>
  );
}
