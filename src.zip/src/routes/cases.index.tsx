import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell } from "@/components/SiteChrome";
import { CASES } from "@/lib/game-data";
import { T, useLang } from "@/lib/i18n";

export const Route = createFileRoute("/cases/")({
  head: () => ({
    meta: [
      { title: "Kho hồ sơ điều tra — VERITAS.EXE" },
      {
        name: "description",
        content: "Danh sách hồ sơ tin giả: ảnh AI, lừa đảo tin nhắn, deepfake tài chính.",
      },
      { property: "og:title", content: "Kho hồ sơ điều tra — VERITAS.EXE" },
      {
        property: "og:description",
        content: "Chọn một hồ sơ và bắt đầu luyện phản xạ kiểm chứng.",
      },
    ],
  }),
  component: CasesPage,
});

function CasesPage() {
  const { t } = useLang();

  return (
    <PageShell>
      <section className="mx-auto max-w-6xl px-4 py-16">
        <p className="label-mono text-accent">{t(T.hubKicker)}</p>
        <h1 className="mt-3 text-4xl font-bold sm:text-5xl">{t(T.hubTitle)}</h1>
        <p className="mt-4 max-w-2xl text-muted-foreground">{t(T.hubText)}</p>

        <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {CASES.map((c) => {
            const locked = c.status === "locked";
            return (
              <article key={c.id} className="pixel-frame flex flex-col">
                <div className="relative border-b-[3px] border-border">
                  <img
                    src={c.image}
                    alt={`Case file ${c.code}`}
                    loading="lazy"
                    width={768}
                    height={576}
                    className="pixelated aspect-[4/3] w-full object-cover"
                  />
                  {locked && (
                    <div className="absolute inset-0 grid place-items-center bg-background/80">
                      <p className="font-display text-2xl font-bold tracking-widest text-primary">
                        {t(T.locked)}
                      </p>
                    </div>
                  )}
                </div>
                <div className="flex flex-1 flex-col p-5">
                  <div className="flex items-center gap-2">
                    <span className="border-[3px] border-gold px-2 py-0.5 font-display text-xs font-bold text-gold">
                      {c.code}
                    </span>
                    <span className="label-mono text-muted-foreground">
                      {c.minutes} {t(T.minutes)} · {c.modules} {t(T.modules)}
                    </span>
                  </div>
                  <h2 className="mt-3 text-xl font-bold">{t(c.title)}</h2>
                  <p className="mt-2 flex-1 text-sm text-muted-foreground">{t(c.tagline)}</p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {c.tags.map((tag) => (
                      <span
                        key={tag.en}
                        className="border-[3px] border-input px-2 py-0.5 font-display text-[0.7rem] uppercase tracking-widest text-foreground"
                      >
                        {t(tag)}
                      </span>
                    ))}
                  </div>
                  <Link
                    to={`/cases/${c.id}`}
                    className="mt-5 inline-flex items-center justify-center border-[3px] border-primary bg-primary px-4 py-2 font-display text-xs font-bold uppercase tracking-[0.18em] text-primary-foreground shadow-[4px_4px_0_0_var(--accent)] transition-colors hover:border-accent hover:bg-accent hover:text-accent-foreground"
                  >
                    {locked ? t(T.openFile) : t(T.investigate)}
                  </Link>
                </div>
              </article>
            );
          })}
        </div>
      </section>
    </PageShell>
  );
}
