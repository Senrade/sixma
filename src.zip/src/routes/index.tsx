import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/SiteChrome";
import { PixelLink } from "@/components/PixelButton";
import { CASES, AUDIENCES, FAQ } from "@/lib/game-data";
import { T, useLang } from "@/lib/i18n";
import heroImg from "@/assets/hero-pixel.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "VERITAS.EXE — Game pixel cyberpunk chống tin giả" },
      {
        name: "description",
        content:
          "Điều tra hồ sơ tin giả trong thành phố neon: soi bằng chứng, chất vấn lời khẳng định, lần theo chuỗi lan truyền. Song ngữ Việt–Anh.",
      },
      { property: "og:title", content: "VERITAS.EXE — Game pixel chống tin giả" },
      {
        property: "og:description",
        content: "Luyện phản xạ kiểm chứng qua các hồ sơ điều tra ngắn, phong cách pixel cyberpunk.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  const { t } = useLang();
  const featured = CASES[0];

  return (
    <PageShell>
      {/* HERO */}
      <section className="relative overflow-hidden border-b-[3px] border-border">
        <img
          src={heroImg}
          alt="Robot điều tra viên soi bảng tin ảo trong thành phố neon"
          width={1536}
          height={960}
          className="pixelated absolute inset-0 size-full object-cover opacity-45"
        />
        <div className="absolute inset-0 bg-background/55" />
        <div className="relative mx-auto grid max-w-6xl gap-8 px-4 py-24 lg:py-32">
          <p className="label-mono text-neon">{t(T.heroKicker)}</p>
          <h1 className="max-w-3xl text-5xl font-bold leading-[1.05] text-foreground text-glow sm:text-7xl">
            VERITAS<span className="text-accent text-glow-accent">.EXE</span>
          </h1>
          <p className="max-w-2xl text-lg text-foreground/90">{t(T.heroText)}</p>
          <div className="flex flex-wrap gap-4">
            <PixelLink to="/cases" variant="gold">
              {t(T.heroCta1)}
            </PixelLink>
            <PixelLink to="/redeem" variant="ghost">
              {t(T.heroCta2)}
            </PixelLink>
          </div>
          <div className="mt-4 grid max-w-3xl grid-cols-2 gap-3 sm:grid-cols-4">
            {[
              ["03", T.statCases],
              ["10", T.statModules],
              ["45", T.statMinutes],
              ["00", T.statAccounts],
            ].map(([n, l]) => (
              <div key={n as string} className="pixel-frame-flat border-gold/70 px-3 py-3">
                <p className="font-display text-2xl font-bold text-gold">{n as string}</p>
                <p className="label-mono text-muted-foreground">
                  {t(l as { vi: string; en: string })}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* WHAT IT IS */}
      <section className="mx-auto max-w-6xl px-4 py-20">
        <p className="label-mono text-accent">{t(T.whatKicker)}</p>
        <h2 className="mt-4 max-w-3xl text-3xl font-bold sm:text-4xl">{t(T.whatTitle)}</h2>
        <p className="mt-4 max-w-2xl text-muted-foreground">{t(T.whatText)}</p>

        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {AUDIENCES.map((a) => (
            <article key={a.icon} className="pixel-frame p-6">
              <span className="font-display text-3xl text-neon">{a.icon}</span>
              <h3 className="mt-4 text-xl font-bold">{t(a.title)}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{t(a.text)}</p>
            </article>
          ))}
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="border-y-[3px] border-border bg-surface/60">
        <div className="pixel-grid mx-auto max-w-6xl px-4 py-20">
          <p className="label-mono text-primary">{t(T.howKicker)}</p>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {featured.steps.map((s) => (
              <article key={s.n} className="pixel-frame-flat p-6">
                <p className="font-display text-4xl font-bold text-gold">{s.n}</p>
                <h3 className="mt-3 text-xl font-bold">{t(s.title)}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{t(s.text)}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURED CASE */}
      <section className="mx-auto max-w-6xl px-4 py-20">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="label-mono text-accent">{t(T.caseKicker)}</p>
            <h2 className="mt-3 text-3xl font-bold sm:text-4xl">{t(T.caseTitle)}</h2>
          </div>
          <PixelLink to="/cases" variant="ghost">
            {t(T.seeAll)}
          </PixelLink>
        </div>

        <article className="pixel-frame mt-8 grid gap-0 md:grid-cols-[280px_1fr]">
          <img
            src={featured.image}
            alt={`Case file ${featured.code}`}
            loading="lazy"
            width={768}
            height={576}
            className="pixelated size-full border-b-[3px] border-border object-cover md:border-b-0 md:border-r-[3px]"
          />
          <div className="p-6">
            <div className="flex flex-wrap items-center gap-3">
              <span className="border-[3px] border-gold px-2 py-1 font-display text-xs font-bold tracking-widest text-gold">
                {featured.code}
              </span>
              <span className="border-[3px] border-destructive bg-destructive px-2 py-1 font-display text-xs font-bold tracking-widest text-destructive-foreground">
                {t(T.level)} {featured.threat}
              </span>
              <span className="label-mono text-muted-foreground">
                {featured.minutes} {t(T.minutes)} · {featured.modules} {t(T.modules)}
              </span>
            </div>
            <h3 className="mt-4 text-2xl font-bold">{t(featured.title)}</h3>
            <p className="mt-2 text-muted-foreground">{t(featured.tagline)}</p>
            <div className="mt-6">
              <PixelLink to={`/cases/${featured.id}`}>{t(T.investigate)}</PixelLink>
            </div>
          </div>
        </article>
      </section>

      {/* FAQ */}
      <section className="border-t-[3px] border-border bg-surface/60">
        <div className="mx-auto max-w-4xl px-4 py-20">
          <p className="label-mono text-neon">{t(T.faqKicker)}</p>
          <h2 className="mt-3 text-3xl font-bold sm:text-4xl">{t(T.faqTitle)}</h2>
          <div className="mt-8 grid gap-4">
            {FAQ.map((f, i) => (
              <details key={f.q.en} className="pixel-frame-flat p-5">
                <summary className="cursor-pointer font-display text-base font-semibold text-foreground marker:text-primary">
                  <span className="mr-3 text-primary">{String(i + 1).padStart(2, "0")}</span>
                  {t(f.q)}
                </summary>
                <p className="mt-3 text-sm text-muted-foreground">{t(f.a)}</p>
              </details>
            ))}
          </div>
        </div>
      </section>
    </PageShell>
  );
}
