import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/SiteChrome";
import { PixelLink } from "@/components/PixelButton";
import { KNOWLEDGE_CARDS } from "@/lib/game-data";
import { T, useLang } from "@/lib/i18n";

export const Route = createFileRoute("/knowledge")({
  head: () => ({
    meta: [
      { title: "Sổ tay kiểm chứng — VERITAS.EXE" },
      {
        name: "description",
        content: "Sổ tay pixel về dấu hiệu tin giả: ảnh AI, deepfake, móc câu cảm xúc, số liệu ảo.",
      },
      { property: "og:title", content: "Sổ tay kiểm chứng — VERITAS.EXE" },
      { property: "og:description", content: "Những dấu hiệu nhận biết tin giả, gói gọn thành thẻ." },
    ],
  }),
  component: KnowledgePage,
});

function KnowledgePage() {
  const { t } = useLang();

  return (
    <PageShell>
      <section className="mx-auto max-w-6xl px-4 py-16">
        <p className="label-mono text-neon">{t(T.kbKicker)}</p>
        <h1 className="mt-3 text-4xl font-bold sm:text-5xl">{t(T.kbTitle)}</h1>
        <p className="mt-4 max-w-2xl text-muted-foreground">{t(T.kbText)}</p>

        <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {KNOWLEDGE_CARDS.map((c) => (
            <article key={c.title.en} className="pixel-frame p-6">
              <span className="border-[3px] border-accent px-2 py-0.5 font-display text-[0.7rem] uppercase tracking-widest text-accent">
                {t(c.tag)}
              </span>
              <h2 className="mt-4 text-xl font-bold">{t(c.title)}</h2>
              <p className="mt-2 text-sm text-muted-foreground">{t(c.text)}</p>
            </article>
          ))}
        </div>

        <div className="mt-12 flex flex-wrap gap-4">
          <PixelLink to="/cases" variant="gold">
            {t(T.seeAll)}
          </PixelLink>
          <PixelLink to="/dashboard" variant="ghost">
            {t(T.navDashboard)}
          </PixelLink>
        </div>
      </section>
    </PageShell>
  );
}
