import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { PixelLink } from "./PixelButton";
import { T, useLang, type Lang } from "@/lib/i18n";

const NAV = [
  { to: "/", label: T.navHome },
  { to: "/cases", label: T.navCases },
  { to: "/knowledge", label: T.navKnowledge },
  { to: "/dashboard", label: T.navDashboard },
  { to: "/redeem", label: T.navRedeem },
];

export function LanguageSwitch({ className = "" }: { className?: string }) {
  const { lang, setLang } = useLang();
  const options: { id: Lang; label: string }[] = [
    { id: "vi", label: "VI" },
    { id: "en", label: "EN" },
  ];

  return (
    <div
      className={`inline-flex border-[3px] border-border bg-surface-2 ${className}`}
      role="group"
      aria-label="Ngôn ngữ / Language"
    >
      {options.map((o) => (
        <button
          key={o.id}
          onClick={() => setLang(o.id)}
          aria-pressed={lang === o.id}
          className={`px-3 py-2 font-display text-xs font-bold uppercase tracking-[0.18em] transition-colors ${
            lang === o.id
              ? "bg-primary text-primary-foreground"
              : "text-muted-foreground hover:text-primary"
          }`}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const { t } = useLang();

  return (
    <header className="sticky top-0 z-50 border-b-[3px] border-border bg-background/95 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3">
        <Link to="/" className="flex items-center gap-3">
          <span className="grid size-10 place-items-center border-[3px] border-primary bg-primary font-display text-lg font-bold text-primary-foreground">
            V
          </span>
          <span className="font-display text-lg font-bold tracking-[0.12em] text-foreground">
            VERITAS<span className="text-accent">.EXE</span>
          </span>
        </Link>

        <nav className="hidden items-center gap-1 lg:flex">
          {NAV.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              activeOptions={{ exact: item.to === "/" }}
              activeProps={{
                className: "border-primary bg-primary text-primary-foreground",
              }}
              inactiveProps={{
                className:
                  "border-transparent text-muted-foreground hover:border-primary hover:text-primary",
              }}
              className="border-[3px] px-3 py-2 font-display text-xs font-semibold uppercase tracking-[0.14em]"
            >
              {t(item.label)}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <LanguageSwitch />
          <PixelLink to="/dashboard" variant="accent" className="hidden px-4 py-2 text-xs lg:inline-flex">
            {t(T.navStart)}
          </PixelLink>
          <button
            aria-label="Menu"
            onClick={() => setOpen((v) => !v)}
            className="border-[3px] border-border px-3 py-2 font-display text-xs uppercase tracking-widest text-foreground lg:hidden"
          >
            {open ? t(T.close) : t(T.menu)}
          </button>
        </div>
      </div>

      {open && (
        <nav className="grid gap-1 border-t-[3px] border-border bg-surface px-4 py-3 lg:hidden">
          {NAV.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              onClick={() => setOpen(false)}
              className="border-[3px] border-transparent px-3 py-2 font-display text-sm uppercase tracking-widest text-foreground hover:border-primary hover:text-primary"
            >
              {t(item.label)}
            </Link>
          ))}
        </nav>
      )}
    </header>
  );
}

export function SiteFooter() {
  const { t } = useLang();

  return (
    <footer className="border-t-[3px] border-border bg-surface">
      <div className="mx-auto flex max-w-6xl flex-col gap-4 px-4 py-8 sm:flex-row sm:items-center sm:justify-between">
        <p className="font-display text-sm uppercase tracking-[0.18em] text-primary">
          {t(T.footerTag)}
        </p>
        <p className="max-w-md text-sm text-muted-foreground">{t(T.footerText)}</p>
        <LanguageSwitch />
      </div>
    </footer>
  );
}

export function PageShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">{children}</main>
      <SiteFooter />
    </div>
  );
}
