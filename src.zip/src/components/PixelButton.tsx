import { Link } from "@tanstack/react-router";
import type { ComponentProps, ReactNode } from "react";
import { cn } from "@/lib/utils";

const base =
  "inline-flex items-center justify-center gap-2 border-[3px] px-5 py-3 font-display text-sm font-bold uppercase tracking-[0.18em] transition-all active:translate-x-[2px] active:translate-y-[2px] active:shadow-none disabled:opacity-50";

const variants = {
  primary:
    "border-primary bg-primary text-primary-foreground shadow-[4px_4px_0_0_var(--accent)] hover:bg-accent hover:text-accent-foreground hover:border-accent hover:shadow-[4px_4px_0_0_var(--primary)]",
  accent:
    "border-accent bg-accent text-accent-foreground shadow-[4px_4px_0_0_var(--primary)] hover:bg-primary hover:text-primary-foreground hover:border-primary",
  gold:
    "border-gold bg-gold text-gold-foreground shadow-[4px_4px_0_0_var(--accent)] hover:bg-warn hover:border-warn hover:text-gold-foreground hover:shadow-[4px_4px_0_0_var(--gold)]",
  ghost:
    "border-border bg-surface text-foreground shadow-[4px_4px_0_0_color-mix(in_oklab,var(--primary)_45%,transparent)] hover:border-primary hover:text-primary",
} as const;

export function PixelButton({
  variant = "primary",
  className,
  children,
  ...props
}: ComponentProps<"button"> & { variant?: keyof typeof variants }) {
  return (
    <button className={cn(base, variants[variant], className)} {...props}>
      {children}
    </button>
  );
}

export function PixelLink({
  to,
  variant = "primary",
  className,
  children,
}: {
  to: string;
  variant?: keyof typeof variants;
  className?: string;
  children: ReactNode;
}) {
  return (
    <Link to={to} className={cn(base, variants[variant], className)}>
      {children}
    </Link>
  );
}
