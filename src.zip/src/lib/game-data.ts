import caseR001 from "@/assets/case-r001.jpg";
import caseR002 from "@/assets/case-r002.jpg";
import caseR003 from "@/assets/case-r003.jpg";
import { bi } from "@/lib/i18n";

type Pair = { vi: string; en: string };

export type GameCase = {
  id: string;
  code: string;
  title: Pair;
  tagline: Pair;
  tags: Pair[];
  minutes: number;
  modules: number;
  threat: "RED" | "AMBER" | "GREEN";
  status: "open" | "locked" | "cleared";
  image: string;
  briefing: Pair;
  evidence: { label: string; note: Pair }[];
  steps: { n: string; title: Pair; text: Pair }[];
};

export const CASES: GameCase[] = [
  {
    id: "R001",
    code: "R001",
    title: bi("Lớp học chưa từng tồn tại", "The Classroom That Never Happened"),
    tagline: bi(
      "Một tấm ảnh lớp học lan truyền — nhưng bảng chữ trên màn hình bị méo.",
      "A viral classroom photo — but the text on the screen is warped.",
    ),
    tags: [bi("Giáo dục", "Education"), bi("Ảnh AI", "AI imagery")],
    minutes: 15,
    modules: 3,
    threat: "RED",
    status: "open",
    image: caseR001,
    briefing: bi(
      "Một bài đăng khoe 'lớp học robot đầu tiên của thành phố' đạt 40.000 lượt chia sẻ trong 6 giờ. Không có báo nào đưa tin. Hãy soi bằng chứng trước khi tin.",
      "A post about 'the city's first robot classroom' hit 40,000 shares in six hours. No newsroom covered it. Inspect the evidence before you trust it.",
    ),
    evidence: [
      { label: "IMG_01", note: bi("Chữ trên bảng bị bóp méo, không đọc được", "Text on the board is warped and unreadable") },
      { label: "META", note: bi("Không có dữ liệu EXIF của máy ảnh", "No camera EXIF data present") },
      { label: "SRC", note: bi("Tài khoản đăng mới tạo 3 ngày trước", "Posting account was created three days ago") },
    ],
    steps: [
      {
        n: "01",
        title: bi("Soi bằng chứng", "Inspect evidence"),
        text: bi(
          "Tìm điểm bất thường trong ảnh thay vì tin vào ấn tượng đầu tiên.",
          "Locate visual inconsistencies instead of trusting first impressions.",
        ),
      },
      {
        n: "02",
        title: bi("Chất vấn lời khẳng định", "Question the claim"),
        text: bi(
          "Đánh dấu chính xác câu chữ đang gieo nỗi sợ hoặc lập luận sai.",
          "Mark the exact language pushing fear or faulty reasoning.",
        ),
      },
      {
        n: "03",
        title: bi("Lần theo chuỗi lan truyền", "Trace the chain"),
        text: bi(
          "Dựng lại trình tự đưa người đọc từ cái móc câu tới thiệt hại.",
          "Rebuild the sequence that moves a person from hook to harm.",
        ),
      },
    ],
  },
  {
    id: "R002",
    code: "R002",
    title: bi("Tin nhắn trúng thưởng lúc 2 giờ sáng", "The 2AM Prize Message"),
    tagline: bi(
      "Áp lực thời gian là vũ khí. Ai đang bấm đồng hồ?",
      "Time pressure is a weapon. Who is running the clock?",
    ),
    tags: [bi("Lừa đảo", "Scams"), bi("Gia đình", "Families")],
    minutes: 12,
    modules: 3,
    threat: "AMBER",
    status: "locked",
    image: caseR002,
    briefing: bi(
      "Hồ sơ được mở khoá sau khi hoàn tất hồ sơ R001.",
      "This dossier unlocks after case R001 is completed.",
    ),
    evidence: [],
    steps: [],
  },
  {
    id: "R003",
    code: "R003",
    title: bi("Gương mặt vay mượn", "The Borrowed Face"),
    tagline: bi(
      "Video deepfake của một người nổi tiếng kêu gọi đầu tư.",
      "A deepfaked celebrity video pushing an investment scheme.",
    ),
    tags: [bi("Deepfake", "Deepfake"), bi("Tài chính", "Finance")],
    minutes: 18,
    modules: 4,
    threat: "RED",
    status: "locked",
    image: caseR003,
    briefing: bi(
      "Hồ sơ được mở khoá sau khi hoàn tất hồ sơ R002.",
      "This dossier unlocks after case R002 is completed.",
    ),
    evidence: [],
    steps: [],
  },
];

export const FAQ = [
  {
    q: bi("Tôi có cần tài khoản để chơi không?", "Do I need an account to play?"),
    a: bi(
      "Không. Bản demo này lưu tiến trình ngay trên trình duyệt, bạn có thể đi hết lộ trình mà không cần đăng ký.",
      "No. This demo keeps progress in your browser, so you can finish the whole path without signing up.",
    ),
  },
  {
    q: bi("Đây có phải hồ sơ chính thức của UNESCO?", "Are these official UNESCO cases?"),
    a: bi(
      "Không. Đây là một dự án độc lập về năng lực truyền thông, các hồ sơ đều là kịch bản giáo dục nguyên bản.",
      "No. This is an independent media-literacy project; every case is an original educational scenario.",
    ),
  },
  {
    q: bi("Vì sao các hồ sơ sau bị khoá?", "Why are later cases locked?"),
    a: bi(
      "Mỗi hồ sơ xây một thói quen kiểm chứng. Hoàn tất hồ sơ trước sẽ mở khoá hồ sơ kế tiếp, tránh việc bỏ qua lộ trình.",
      "Each case builds one verification habit. Finishing the previous case unlocks the next and prevents skipping the guided path.",
    ),
  },
  {
    q: bi(
      "Một điểm bất thường có đủ chứng minh ảnh do AI tạo không?",
      "Does one anomaly prove an image is AI-generated?",
    ),
    a: bi(
      "Không. Một dấu hiệu chỉ là giả thuyết. Người điều tra giỏi luôn cộng dồn nhiều bằng chứng độc lập.",
      "No. A single signal is only a hypothesis. Good investigators stack several independent clues.",
    ),
  },
];

export const AUDIENCES = [
  {
    title: bi("Học sinh", "Students"),
    text: bi(
      "Rèn phản xạ kiểm chứng trước khi phản ứng với nội dung lan truyền.",
      "Build verification reflexes before reacting to viral content.",
    ),
    icon: "▚",
  },
  {
    title: bi("Gia đình", "Families"),
    text: bi(
      "Cùng nhau bàn về lừa đảo, áp lực cảm xúc và những lời hứa đáng ngờ.",
      "Talk through scams, emotional pressure and suspicious promises together.",
    ),
    icon: "▞",
  },
  {
    title: bi("Giáo viên", "Educators"),
    text: bi(
      "Dùng các hồ sơ ngắn cho giờ thực hành năng lực truyền thông.",
      "Use compact cases for guided media-literacy practice.",
    ),
    icon: "▜",
  },
];

export const KNOWLEDGE_CARDS = [
  {
    tag: bi("Kỹ thuật", "Technical"),
    title: bi("Ảnh do AI tạo", "AI-generated images"),
    text: bi(
      "Chữ méo, ngón tay thừa, phản chiếu sai. Một dấu hiệu chỉ là giả thuyết — hãy cộng dồn.",
      "Warped text, extra fingers, impossible reflections. One clue is a hypothesis — stack them.",
    ),
  },
  {
    tag: bi("Cảm xúc", "Emotion"),
    title: bi("Móc câu sợ hãi", "Fear hooks"),
    text: bi(
      "Nội dung ép bạn hành động ngay thường đang bán cho bạn một quyết định vội vàng.",
      "Content that demands instant action is usually selling you a rushed decision.",
    ),
  },
  {
    tag: bi("Nguồn", "Sources"),
    title: bi("Truy ngược nguồn gốc", "Trace the origin"),
    text: bi(
      "Ai đăng đầu tiên? Tài khoản tồn tại bao lâu? Có cơ quan nào xác nhận độc lập không?",
      "Who posted first? How old is the account? Has any independent body confirmed it?",
    ),
  },
  {
    tag: bi("Số liệu", "Data"),
    title: bi("Thống kê không nguồn", "Unsourced statistics"),
    text: bi(
      "Con số ấn tượng không kèm khảo sát, mẫu và thời điểm là con số chưa thể tin.",
      "An impressive number without a study, sample and date is not yet a fact.",
    ),
  },
  {
    tag: bi("Video", "Video"),
    title: bi("Dấu vết deepfake", "Deepfake tells"),
    text: bi(
      "Khớp môi lệch, ánh sáng viền mặt bất thường, nhịp chớp mắt máy móc.",
      "Lip-sync drift, odd edge lighting around the face, mechanical blink rhythm.",
    ),
  },
  {
    tag: bi("Thói quen", "Habit"),
    title: bi("Quy tắc dừng 10 giây", "The 10-second pause"),
    text: bi(
      "Trước khi chia sẻ: nguồn, ngày, mục đích. Ba câu hỏi, mười giây.",
      "Before sharing: source, date, motive. Three questions, ten seconds.",
    ),
  },
];
