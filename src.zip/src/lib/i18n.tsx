import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Lang = "vi" | "en";
type Pair = { vi: string; en: string };

const STORAGE_KEY = "veritas-lang";

const LangContext = createContext<{
  lang: Lang;
  setLang: (l: Lang) => void;
  toggle: () => void;
}>({ lang: "vi", setLang: () => {}, toggle: () => {} });

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("vi");

  useEffect(() => {
    const stored = window.localStorage.getItem(STORAGE_KEY);
    if (stored === "vi" || stored === "en") setLangState(stored);
  }, []);

  const setLang = (l: Lang) => {
    setLangState(l);
    window.localStorage.setItem(STORAGE_KEY, l);
    document.documentElement.lang = l;
  };

  return (
    <LangContext.Provider value={{ lang, setLang, toggle: () => setLang(lang === "vi" ? "en" : "vi") }}>
      {children}
    </LangContext.Provider>
  );
}

export function useLang() {
  const ctx = useContext(LangContext);
  const t = (p: Pair) => p[ctx.lang];
  return { ...ctx, t };
}

export const bi = (vi: string, en: string): Pair => ({ vi, en });

/* ---------- UI copy ---------- */

export const T = {
  navHome: bi("Trang chủ", "Home"),
  navCases: bi("Hồ sơ", "Case hub"),
  navKnowledge: bi("Kiến thức", "Knowledge"),
  navDashboard: bi("Bảng điều khiển", "Dashboard"),
  navRedeem: bi("Nhập mã", "Redeem"),
  navStart: bi("Bắt đầu", "Start"),
  menu: bi("Menu", "Menu"),
  close: bi("Đóng", "Close"),
  footerTag: bi("VERITAS.EXE — bản demo giao diện", "VERITAS.EXE — UI demo build"),
  footerText: bi(
    "Dự án độc lập về năng lực truyền thông. Mọi hồ sơ đều là kịch bản giáo dục hư cấu.",
    "An independent media-literacy project. Every case is a fictional educational scenario.",
  ),

  heroKicker: bi("Học kiểm chứng bằng cách chơi", "Media literacy, learned by doing"),
  heroText: bi(
    "Một game tương tác về năng lực truyền thông dành cho học sinh, gia đình và giáo viên. Giải các hồ sơ mô phỏng trước khi áp lực thật xuất hiện ngoài đời.",
    "An interactive media-literacy game for students, families and educators. Work through realistic cases before the same pressure shows up in real life.",
  ),
  heroCta1: bi("Mở kho hồ sơ", "Open case hub"),
  heroCta2: bi("Nhập mã thẻ", "Redeem card"),
  statCases: bi("Hồ sơ", "Cases"),
  statModules: bi("Mô-đun", "Modules"),
  statMinutes: bi("Phút", "Minutes"),
  statAccounts: bi("Tài khoản", "Accounts"),

  whatKicker: bi("Đây là gì", "What it is"),
  whatTitle: bi(
    "Tập dừng lại một nhịp trước khi tin hoặc chia sẻ",
    "Practice the pause before you trust or share",
  ),
  whatText: bi(
    "VERITAS.EXE biến các mô-típ tin giả thành những cuộc điều tra ngắn. Người chơi soi tư liệu gốc, gọi tên thủ thuật thuyết phục và lần theo cách một lời khẳng định vô căn cứ lớn dần.",
    "VERITAS.EXE turns misinformation patterns into short investigations. Players inspect the source material, name the persuasive technique, and trace how an unsupported claim grows.",
  ),
  howKicker: bi("Một cuộc điều tra diễn ra thế nào", "How an investigation works"),
  caseKicker: bi("Hồ sơ vụ án", "Case files"),
  caseTitle: bi("Bắt đầu cuộc điều tra đầu tiên", "Start the first investigation"),
  seeAll: bi("Xem tất cả", "Browse all"),
  investigate: bi("Điều tra →", "Investigate →"),
  openFile: bi("Xem hồ sơ", "View file"),
  faqKicker: bi("Hỏi và đáp", "Questions and answers"),
  faqTitle: bi("Câu hỏi thường gặp", "Frequently asked questions"),
  minutes: bi("phút", "min"),
  modules: bi("mô-đun", "modules"),
  level: bi("MỨC", "LEVEL"),

  hubKicker: bi("Kho hồ sơ", "Case hub"),
  hubTitle: bi("Chọn hồ sơ điều tra", "Pick an investigation"),
  hubText: bi(
    "Mỗi hồ sơ rèn một thói quen kiểm chứng. Hoàn tất hồ sơ trước để mở khoá hồ sơ kế tiếp.",
    "Each case builds one verification habit. Finish the previous file to unlock the next dossier.",
  ),
  locked: bi("▮ ĐÃ KHOÁ", "▮ LOCKED"),
  fileWord: bi("HỒ SƠ", "FILE"),
  sealedTitle: bi("Hồ sơ đang niêm phong", "Dossier sealed"),
  sealedText: bi(
    "Hoàn tất hồ sơ trước đó để mở khoá bằng chứng của vụ này.",
    "Complete the previous case to unlock this evidence set.",
  ),
  backToHub: bi("Quay lại kho hồ sơ", "Back to case hub"),

  mod1: bi("Mô-đun 01 · Soi bằng chứng", "Module 01 · Inspect evidence"),
  mod1Title: bi(
    "Bấm vào từng mảnh bằng chứng bất thường",
    "Click each anomalous piece of evidence",
  ),
  unanalyzed: bi("??? — chưa phân tích", "??? — not analysed"),
  progress: bi("Tiến độ", "Progress"),
  mod2: bi("Mô-đun 02 · Chất vấn lời khẳng định", "Module 02 · Question the claim"),
  mod2Title: bi("Bạn sẽ làm gì tiếp theo?", "What do you do next?"),
  choiceA: bi("Chia sẻ ngay cho nhóm lớp", "Share it to the class group right away"),
  choiceB: bi("Soi kỹ ảnh và tìm nguồn gốc", "Inspect the image and trace the source"),
  choiceC: bi("Bỏ qua, không quan tâm", "Scroll past and ignore it"),
  verdictRight: bi(
    "Chuẩn. Kiểm chứng trước, phản ứng sau — đó là phản xạ của người điều tra.",
    "Correct. Verify first, react second — that is the investigator reflex.",
  ),
  verdictWrong: bi(
    "Chưa ổn. Bỏ qua hoặc lan truyền đều để tin giả tiếp tục sống.",
    "Not quite. Ignoring or amplifying both keep the false claim alive.",
  ),
  mod3: bi("Mô-đun 03 · Lần theo chuỗi lan truyền", "Module 03 · Trace the chain"),
  chain1: bi("Móc câu cảm xúc", "Emotional hook"),
  chain2: bi("Chia sẻ hàng loạt", "Mass sharing"),
  chain3: bi("Bình luận củng cố", "Reinforcing comments"),
  chain4: bi("Thiệt hại thật", "Real-world harm"),
  submit: bi("Nộp kết luận", "Submit findings"),

  kbKicker: bi("Sổ tay", "Field guide"),
  kbTitle: bi("Kiến thức kiểm chứng", "Verification knowledge"),
  kbText: bi(
    "Thu thập thẻ kiến thức khi bạn hoàn thành các mô-đun. Mỗi thẻ là một công cụ dùng được ngay ngoài đời.",
    "Collect knowledge cards as you clear modules. Each one is a tool you can use in real life today.",
  ),

  dashKicker: bi("Hồ sơ điều tra viên", "Investigator profile"),
  dashTitle: bi("Bảng điều khiển", "Dashboard"),
  statDone: bi("Hồ sơ hoàn tất", "Cases cleared"),
  statCards: bi("Thẻ kiến thức", "Knowledge cards"),
  statStreak: bi("Ngày liên tiếp", "Day streak"),
  statScore: bi("Điểm tín nhiệm", "Trust score"),
  caseProgress: bi("Tiến độ hồ sơ", "Case progress"),
  continueCase: bi("Tiếp tục điều tra", "Continue investigating"),
  badges: bi("Huy hiệu", "Badges"),
  badge1: bi("Người soi ảnh", "Image spotter"),
  badge2: bi("Thợ săn nguồn", "Source hunter"),
  badge3: bi("Chống hoảng loạn", "Panic-proof"),
  badge4: bi("Bậc thầy dừng 10s", "10-second master"),

  redeemKicker: bi("Thẻ giấy", "Paper card"),
  redeemTitle: bi("Nhập mã thẻ", "Redeem a card"),
  redeemText: bi("Mã in trên thẻ phát tại lớp học có dạng", "Codes handed out in class look like"),
  redeemLabel: bi("Mã thẻ", "Card code"),
  redeemBtn: bi("Kích hoạt", "Activate"),
  redeemOk: bi(
    "✔ Mã hợp lệ — hồ sơ mới đã mở khoá (demo giao diện)",
    "✔ Valid code — a new dossier is unlocked (UI demo)",
  ),
  redeemBad: bi("✖ Mã không đúng định dạng VRT-XXXX", "✖ Code must match the VRT-XXXX format"),
};
